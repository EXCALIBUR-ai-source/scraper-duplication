// background.js
// Receives {uuid, url} and returns bookmark/history info

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "CHECK_UUID") {
    const { uuid, url } = msg;
    Promise.all([
      searchBookmarks(uuid),
      searchHistory(uuid)
    ]).then(([bmResults, histResults]) => {
      const bookmarkMatches = bmResults || [];
      const historyMatches = histResults || [];
      const lastVisit = historyMatches.length
        ? new Date(Math.max(...historyMatches.map(r => r.lastVisitTime || 0))).toISOString()
        : null;

      sendResponse({
        ok: true,
        uuid,
        url,
        bookmarkCount: bookmarkMatches.length,
        historyCount: historyMatches.length,
        lastVisit
      });
    }).catch(err => {
      sendResponse({ ok: false, error: String(err) });
    });
    return true; // keep channel open for async sendResponse
  }
});

function searchBookmarks(uuid) {
  return new Promise((resolve) => {
    try {
      chrome.bookmarks.search(uuid, (nodes) => {
        const matches = (nodes || []).filter(n => n.url && n.url.includes(uuid));
        resolve(matches);
      });
    } catch (e) {
      resolve([]);
    }
  });
}

function searchHistory(uuid) {
  return new Promise((resolve) => {
    try {
      chrome.history.search(
        {
          text: uuid,
          startTime: 0,
          maxResults: 1000
        },
        (results) => resolve(results || [])
      );
    } catch (e) {
      resolve([]);
    }
  });
}
