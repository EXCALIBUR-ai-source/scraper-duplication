// content.js
(function () {
  const UUID_REGEX = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;

  function extractUUIDFromURL(u) {
    try {
      const m = String(u).match(UUID_REGEX);
      return m ? m[0] : null;
    } catch {
      return null;
    }
  }

  async function copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (e) {
      try {
        const ta = document.createElement("textarea");
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        ta.remove();
        return true;
      } catch { return false; }
    }
  }

  function showToast(message) {
    const id = "job-uuid-visit-checker-toast";
    if (document.getElementById(id)) return;
    const el = document.createElement("div");
    el.id = id;
    el.textContent = message;
    Object.assign(el.style, {
      position: "fixed",
      right: "16px",
      bottom: "16px",
      background: "#111",
      color: "#fff",
      padding: "10px 12px",
      borderRadius: "10px",
      zIndex: 2147483647,
      fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif",
      boxShadow: "0 8px 24px rgba(0,0,0,0.35)"
    });
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3200);
  }

  async function run() {
    const url = location.href;
    const uuid = extractUUIDFromURL(url);
    if (!uuid) {
      const text = [
        "JOB UUID CHECK",
        `URL: ${url}`,
        "UUID: (none found in URL)",
        "Visited in history: N/A",
        "Bookmarked: N/A"
      ].join("\n");
      await copyToClipboard(text);
      showToast("🔎 No UUID in this URL — result copied.");
      return;
    }

    chrome.runtime.sendMessage({ type: "CHECK_UUID", uuid, url }, async (res) => {
      if (!res || !res.ok) {
        const text = `JOB UUID CHECK\nURL: ${url}\nUUID: ${uuid}\nError: ${res && res.error ? res.error : "Unknown error"}`;
        await copyToClipboard(text);
        showToast("⚠️ Could not check history/bookmarks — copied details.");
        return;
      }

      const visited = res.historyCount > 0;
      const bookmarked = res.bookmarkCount > 0;
      const lines = [
        "JOB UUID CHECK",
        `URL: ${res.url}`,
        `UUID: ${res.uuid}`,
        `Visited in history: ${visited ? "YES" : "NO"}${res.lastVisit ? " (last: " + res.lastVisit + ")" : ""}`,
        `Bookmarked: ${bookmarked ? "YES" : "NO"} (matches: ${res.bookmarkCount})`
      ];
      await copyToClipboard(lines.join("\n"));
      showToast(`📋 ${visited || bookmarked ? "Found matches" : "No matches"} — result copied.`);
    });
  }

  if (document.readyState === "complete" || document.readyState === "interactive") {
    run();
  } else {
    document.addEventListener("DOMContentLoaded", run);
  }
})();
